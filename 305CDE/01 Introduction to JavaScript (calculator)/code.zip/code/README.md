# JavaScript  Basics

## About

This week is simply about getting up and running with JS development, and starting to read (and write) your first JS scripts.

## Priority of Labs

The example scripts are all of similar complexity. They apply simple JS statements and branching to provide interactivity.
