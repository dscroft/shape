# JavaScript Objects and Functions 1

## About

This week covers absolute basics of objects and functions.

## Priority of Labs

The example scripts are all of similar complexity. However, they show you how functions and objects can be used in different ways:

* calling functions
* building objects with regular properties
* building objects whose properties are other functions
* returning objects from functions